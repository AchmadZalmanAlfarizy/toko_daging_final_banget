<?php

$conn = mysqli_connect('localhost','root','','toko_daging') or die('connection failed');

?>